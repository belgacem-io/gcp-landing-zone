#!/bin/sh

cat << PIP > /etc/pip.conf
[global]
timeout=10000
trusted-host=artifactory-build.sofact.bdf.dns.eclair.local
index-url=http://artifactory-build.sofact.bdf.dns.eclair.local/artifactory/api/pypi/pypi/simple
gpgcheck=0
PIP

cat << PIP3 > /etc/pip3.conf
[global]
timeout=10000
trusted-host=artifactory-build.sofact.bdf.dns.eclair.local
index-url=http://artifactory-build.sofact.bdf.dns.eclair.local/artifactory/api/pypi/pypi/simple
gpgcheck=0
PIP3