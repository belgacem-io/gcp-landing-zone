# What is a landing zone?
A landing zone is a well-architected, multi-account Cloud environment that is a starting point from which you can deploy workloads and applications. It provides a baseline to get started with multi-account architecture, identity and access management, governance, data security, network design, and logging.

# Requirements
- Having an Active Directory user account on intra.bdf.local 
- Havingthe flowing authorizations (Ask a TWISTER Team member if needed) :
  1. access to [Cloud Vault](https://homol.cloudvault-ent.bdf.dns.eclair.local/ui/vault/secrets?namespace=%2FBDF%2FAPP%2FCCOE) on namespace /BDF/APP/CCOE. click on [dedicated cockpit cloudvault subscription](https://bdf.cloud.eclair.local/tenant/ccoe/subscription/2884) to add members
  2. developer access on [TWISTER-X landing zone project](https://sofact.banque-france.fr/git/pole-ccoe/twister-c/landing-zone/-/project_members) on SOFACT gitlab 
  3. access to 

# Initialisation steps
1. Update your cntlm proxy config by adding a new listener on your private ip (ex: 192.168.x.z) and restart the service. 
If you are on a [devbox v2.0 VM](https://sofact.banque-france.fr/confluence/x/zoJSQQ), use the  `cntlm-update-account.sh` helper script
Otherwise, find bellow a conf sample :
```
$ cat /etc/cntlm.conf

Domain     intra
Proxy      serai2.bdf.local:8080
Listen     3128
Listen     [YOUR_PRIVATE_IP]:3128
#Allow      127.0.0.1
#Deny       0/0
NoProxy    localhost, 127.0.0.1, 10.*, 192.168.*, 169.254.*, 172.16.*, 172.20.*, *.local, *.private, *.svc, sofact.banque-france.fr
```

2. Setup your docker development environment

```
$ make docker
```

or, if the container is already running (check with `docker ps`)

```
$ make docker_exec
```

3. Install all required libs and tools for your dev environment
```
[Google][]$ source /etc/environment
[Google][]$ make install
```

4. Pull all vault secrets for your target infra
You must specify the following inputs :
 - your personal `username` : use your BdF AD intra.bdf.local account (matricule)
 - the `client code` : bdf or escb
 - the `environment code` (ex: xp, build or run)

```
[Google][]$ source shell/.env --username ixxxxx --client {bdf|escb} --env {xp|build|run}
```
or
```
[Google][]$ source shell/.env -u ixxxxx -c {bdf|escb} -e {xp|build|run}
```

5. Terraform instructions has been wrapper in a make file to add extra steps, you must specify the target module (ex: infra or bp) for each command
```
terraform init    ->    [Google][bdf/xp]$ make init {infra|bp|...}
terraform plan    ->    [Google][bdf/xp]$ make plan {infra|bp|...}
terraform apply   ->    [Google][bdf/xp]$ make apply {infra|bp|...}
terraform refresh ->    [Google][bdf/xp]$ make refresh {infra|bp|...}
```

# Terraform backend
All terraform states are stored in [Artifactory](https://sofact.banque-france.fr/artifactory/bdf-twister-generic-local/landing-zone/Google)

