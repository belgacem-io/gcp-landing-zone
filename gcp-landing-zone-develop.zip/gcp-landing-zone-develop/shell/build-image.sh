#!/bin/bash
set -euo pipefail

IMAGE_VERSION=0.0.0
IMAGE_NAME=$1
CHECK_ALREADY_EXISTS=${2:-'false'}
REGISTRY_PATH=docker.artifactory-build.sofact.bdf.dns.eclair.local
IMAGE_PATH=${REGISTRY_PATH}/twister-automation/${IMAGE_NAME}
http_proxy=http://$(hostname --ip-address | cut -d' ' -f1):3128
https_proxy=http://$(hostname --ip-address | cut -d' ' -f1):3128
no_proxy=localhost,127.0.0.1,.local,.svc,.sofact.banque-france.fr,.private

IMAGE_BUILD_ARGS="--build-arg HTTP_PROXY=$http_proxy
              --build-arg HTTPS_PROXY=$http_proxy
              --build-arg NO_PROXY=$no_proxy
              --build-arg http_proxy=$http_proxy
              --build-arg https_proxy=$http_proxy
              --build-arg no_proxy=$no_proxy"

IMAGE_VERSION=latest
IMAGE_FOLDER=docker_images/$IMAGE_NAME

function login() {
    { # try
          cat ~/.docker/config.json | jq -e '.auths."docker.artifactory-build.sofact.bdf.dns.eclair.local"'
     } || { # catch
         echo "login to registry $REGISTRY_PATH as $(whoami)"
         docker login -u $(whoami) ${REGISTRY_PATH}
     }
}



function force_build() {
    echo "Building image $IMAGE_PATH:$IMAGE_VERSION in folder  $IMAGE_FOLDER"
    docker build ${IMAGE_BUILD_ARGS} -t ${IMAGE_PATH}:${IMAGE_VERSION} ${IMAGE_FOLDER}
}

function push() {
    echo "Pushing image $IMAGE_PATH:$IMAGE_VERSION"
    docker push ${IMAGE_PATH}:${IMAGE_VERSION}
}


IGNORE_PUSH="false"
function build() {
    echo "Checking if image $IMAGE_NAME:$IMAGE_VERSION already exists"
    if DOCKER_CLI_EXPERIMENTAL=enabled docker manifest inspect "${IMAGE_PATH}:${IMAGE_VERSION}" >/dev/null 2>&1; then
        echo "Image already pushed: $IMAGE_NAME:${IMAGE_VERSION}"
        IGNORE_PUSH="true"
    else
        force_build
    fi
}

if [[ $CHECK_ALREADY_EXISTS == "true" ]]; then
    build
else
    force_build
fi

if [[ $IGNORE_PUSH == "true" ]]; then
    echo "Ignoring push"
else
    while true; do
        read -p "Do you wish to push image ${IMAGE_PATH}:${IMAGE_VERSION} ? [Y/n] " yn
        case $yn in
            [Yy]* ) login;push; break;;
            [Nn]* ) exit;;
            * ) echo "Please answer yes or no.";;
        esac
    done
fi

