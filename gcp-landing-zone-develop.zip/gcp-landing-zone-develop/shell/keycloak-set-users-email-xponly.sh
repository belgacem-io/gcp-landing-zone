#!/bin/bash

#TODO : build list from : grep members ../main-iam/terraform.tfvars
GCP_USER_LIST=( "i2118j8" "b846378" "c833476" "i213908" "b856567" "d824277" "i2118bg" "v829881" "t821093" "y850170" "i2146et" "i2146en" "i2118e" \
                "i21180b" "i21180c" "i21180h" "i2118m1" "i2134da" "i2146dm" "i2146fb" "e822484" "i2162kd" "p837673" "s822794" )

# Configuration
KC_ROOT_URL=https://auth-int.cloud.eclair.local/auth/
KC_REALM=cloud-public
KC_ADMIN_CLI_USER=${USER}

#functions
testRC() {
  RC=$?
  MSG=${1:-"Error while executing latest command"}
  RETURN_CODE=${2:-1}
  if [ $RC -ne 0 ] ;
  then
    echo "$MSG, sortie :("
    exit ${RETURN_CODE}
  fi
}

#Installing Keycloak CLI tools
[ ! -d keycloak-client-tools  ] && (
  wget https://repo1.maven.org/maven2/org/keycloak/keycloak-client-cli-dist/17.0.0/keycloak-client-cli-dist-17.0.0.zip
  unzip keycloak-client-cli-dist-17.0.0.zip
  chmod +x keycloak-client-tools/bin/kcadm.sh
)
export PATH=${PATH}:$(dirname $0)/keycloak-client-tools/bin/

#Authentication
echo -n "Please enter your AD password for ${KC_ADMIN_CLI_USER}@intra.bdf.local : "
read -sr KC_ADMIN_CLI_PWD ; echo ""
kcadm.sh config credentials --server ${KC_ROOT_URL} --realm ${KC_REALM} --user ${KC_ADMIN_CLI_USER} --password ${KC_ADMIN_CLI_PWD}
testRC "Keycloak Authentication has failed"

#Loop over users
for username in "${GCP_USER_LIST[@]}"
do
  JSON_USER=$(kcadm.sh get users -r ${KC_REALM} -q username=${username} --fields id,email 2>/dev/null)
  UUID=$(echo "${JSON_USER}" |jq -r '.[].id')
  EMAIL=$(echo "${JSON_USER}" |jq -r '.[].email')
  GCP_ACCOUNT="${username}@gcp.eclair.local"
  if [ "${EMAIL}" != "${GCP_ACCOUNT}" ];
  then
    echo "  ${username} has UUID $UUID, updating email for GCP with [${GCP_ACCOUNT}]"
    kcadm.sh update users/${UUID} -r ${KC_REALM} -s email=${GCP_ACCOUNT}
  else
    echo "  ${username} already has a valid GCP mail on keycloak"
  fi
done
