# Script de MAJ des adresses email sur keycloak

**keycloak-set-users-email-xponly.sh**

Ce script permet de modifier le champ email sur les comptes utilisateurs de Keycloak (issu de l'AD intra), afin de les aligner avec la nomenclature requise sur GCP : *matricule@gcp.eclair.cloud*

## Pré requis 

 - son compte matricule personnel doit etre habilité sur le realm cloudpublic : role manage-user au niveau du client realm managment

### Utilisation

```bash
$ ./keycloak-set-users-email-xponly.sh 
Please enter your AD password for i2118j8@intra.bdf.local : 
Logging into https://auth-int.cloud.eclair.local/auth/ as user i2118j8 of realm cloud-public
  i2118j8 already has a valid GCP mail on keycloak
  b846378 already has a valid GCP mail on keycloak
  c833476 has UUID 0b9417e9-64f0-48ae-98ea-23344237c31f, updating email for GCP with [c833476@gcp.eclair.local]
  i213908 already has a valid GCP mail on keycloak
  b856567 already has a valid GCP mail on keycloak
  d824277 already has a valid GCP mail on keycloak
  i2118bg already has a valid GCP mail on keycloak
  v829881 already has a valid GCP mail on keycloak
  t821093 already has a valid GCP mail on keycloak
  y850170 already has a valid GCP mail on keycloak
  i2146et already has a valid GCP mail on keycloak
  i2146en already has a valid GCP mail on keycloak
```
