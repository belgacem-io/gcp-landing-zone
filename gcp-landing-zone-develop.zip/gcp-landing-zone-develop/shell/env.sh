#!/bin/bash
DIR=$(pwd)
source  $DIR/.env