#!/bin/bash

## Version     : 1.0
## Author      : Arnault MICHEL (i2118j8)
## Description : Bash functions for reading or writing secrets @ cloudvault
## Changelog :
##   02-02-2022 first version
##

## Env vars
VAULT_URL=homol.cloudvault-ent.bdf.dns.eclair.local
VAULT_NAMESPACE="BDF/APP/CCOE/"

## Public Functions 
testRC() {
  RC=$?
  if [ $RC -ne 0 ] ;
  then
    echo "Erreur lors de l'execution de la dernière commande, sortie :("
    exit 1
  fi
}

confirm2continue() {
  read -p "Press y or Y to continue " -n 1 -r
  echo    # (optional) move to a new line
  if [[ ! $REPLY =~ ^[Yy]$ ]]
  then
      [[ "$0" = "$BASH_SOURCE" ]] && exit 1 || return 1 # handle exits from shell or function but don't exit interactive shell
  fi
}

title() {
  TITLE=$1
  DESC=$2
  echo -n "     "
  for (( i=0 ; i<$((${#TITLE}+8)) ; i++ )); do echo -n "#"; done;
  echo -e "\n     ##  $TITLE  ##"
  echo -n "     "
  for (( i=0 ; i<$((${#TITLE}+8)) ; i++ )); do echo -n "#"; done;

  echo -e "\n"
  echo "  Task : ${DESC}"
  echo -e "\n\n"

}


# Read a secret from Vault
# inputs : 2 optional parameters :
#    1 - secret path
#    2 - secret key
# output : return the secret value in the env var VAULT_SECRET_VALUE
# call   : getVaultSecret build7/AD_TECH_ACCOUNT_FOR_PROXY login
#          AD_LOGIN=${VAULT_SECRET_VALUE}
getVaultSecret() {

  VAULT_SECRET_PATH=${1}
  VAULT_SECRET_KEY=${2}

  getVaultToken

  unset VAULT_SECRET_VALUE
  
  echo " Reading secret key ${VAULT_SECRET_KEY} from path ${VAULT_SECRET_ENGINE}/${VAULT_SECRET_PATH}"
  #Loading secret
  VAULT_JSON=$(curl --header "X-Vault-Token: ${VAULT_TOKEN}" \
                    --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
                    --silent \
                    -X GET \
                    https://${VAULT_URL}/v1/${VAULT_SECRET_ENGINE}/data/${VAULT_SECRET_PATH})
  [[ $? -eq 0 ]] && {
    #check if an error was returned
    echo "${VAULT_JSON}" | jq -r .errors --exit-status >/dev/null 2>&1
    [[ $? -ne 0 ]] && VAULT_SECRET_VALUE=$(echo "${VAULT_JSON}" | jq -r .data.data.${VAULT_SECRET_KEY}) \
                   || echo "   warning : Secret not found"
  } || { 
    echo " An error occured while accessing vault \n ${VAULT_JSON}"
    exit 2
  }
}

# Read a secret from Vault
# inputs : 2 parameters :
#    1 - secret path
#    2 - json with key/secret
# output : return true (0) if OK
# call   : setVaultSecret my/path "{\"key1\": \"value1\", \"key2\": \"value2\"}"
setVaultSecret() {
  VAULT_SECRET_PATH=${1}
  VAULT_SECRETS_KEYVALUES_JSON=${2}

  getVaultToken

  #building and verify json strusture
  JSON_DATA="{\"data\":${VAULT_SECRETS_KEYVALUES_JSON}}"
  #echo "${JSON_DATA}" 
  echo "${JSON_DATA}" | jq >/dev/null 2>/dev/null
  [[ $? -ne 0 ]] && { echo "Bad JSON Structure, exiting";exit 2;} #\
                 #||   echo "Json input structure is valid :) "

  echo "  Writing vault secrets on path ${VAULT_SECRET_PATH}"
  #call Vault
  CURL_OUTPUT=$( curl --silent --show-error \
       --header "X-Vault-Token: ${VAULT_TOKEN}" \
       --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
       --request POST \
       --data "${JSON_DATA}" \
       https://${VAULT_URL}/v1/${VAULT_SECRET_ENGINE}/data/${VAULT_SECRET_PATH})
  RC=$?

  [[ $RC -ne 0 ]] && echo "An error occured : ${CURL_OUTPUT}" #\
    # || { echo "${CURL_OUTPUT}" | jq ; }

  return $RC
}

# Private function
vaultAuth() {
  #ask password interactively if not already set
  [[ -z "$VAULT_PASSWORD" ]] && {
    echo "Connecting user ${VAULT_USERNAME} to vault namespace ${VAULT_NAMESPACE}"
    read -sr -p "Please enter your AD Intra password for ${VAULT_USERNAME} : " VAULT_PASSWORD;
    echo ""
  }
  #echo "  Getting Vault Token for AD account ${VAULT_USERNAME}"
  VAULT_TOKEN=$(curl --silent --request POST \
                     --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
                     --data "{\"password\": \"${VAULT_PASSWORD}\"}" \
                     https://${VAULT_URL}/v1/auth/ldap/login/${VAULT_USERNAME} | jq -r ".auth.client_token")
  RC=$?
  [[ $RC -ne 0 || "$VAULT_TOKEN" == "null" ]] && { 
    echo "l'authentification Vault à échoué :(" ;
    exit ${RC};
  }
}

getVaultToken() {
  [[ ! -z "$VAULT_TOKEN" ]] && {
    # On interroge l'API pour savoir si le token est encore valide (et si il l'est, on récpupère le json qui indique sa durée de validité entre autres)
    #TODO : fix me, token reuse is KO, reauth
    TOKEN_STATE=$(curl --silent --request POST \
                       --header "X-Vault-Token: ${VAULT_TOKEN}" \
                       --header "X-Vault-Namespace: ${VAULT_NAMESPACE}" \
                       ${VAULT_URL}/v1/auth/token/lookup-self -o /dev/null)
    if [[ $? -ne 0 ]] 
    then
      # le token n'est plus valide : On le regénre
      vaultAuth
    else
      TOKEN_TTL=$(echo ${TOKEN_STATE} | jq .data.ttl)
      #echo "Vault token still valid for ${TOKEN_TTL} seconds, no need to authenticate again"
      #echo "${TOKEN_STATE}"
    fi
  } || {
    # le token n'a jamais été demandé : on s'authentifie 
    vaultAuth
  }

}
